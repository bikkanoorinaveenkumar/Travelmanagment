package com.example.travelm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelmApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelmApplication.class, args);
	}

}
