package com.example.travelmanagement.configuration;

public class CustomUserDetailsService {

}
