package com.example.travelmanagement.external;

public class TravelApiResponse {

	public void setDestination(String destination) {
		// TODO Auto-generated method stub
		
	}

	public void setInfo(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setDate(String date) {
		// TODO Auto-generated method stub
		
	}

	public void setDate1(String date) {
		// TODO Auto-generated method stub
		
	}

}
