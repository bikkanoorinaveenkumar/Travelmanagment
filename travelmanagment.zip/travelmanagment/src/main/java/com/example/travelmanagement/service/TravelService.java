package com.example.travelmanagement.service;

public interface TravelService {
    
}

