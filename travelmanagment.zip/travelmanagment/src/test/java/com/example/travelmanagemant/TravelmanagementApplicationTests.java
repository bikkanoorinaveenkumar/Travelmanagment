package com.example.travelmanagemant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
